#define EUCLIDEAN_DISTANCE 3.0
#define cluster_threshold 10