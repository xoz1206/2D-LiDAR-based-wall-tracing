#include <object_manager/AVCInterface.h>

AVCInterface* AVCInterface::self = nullptr;