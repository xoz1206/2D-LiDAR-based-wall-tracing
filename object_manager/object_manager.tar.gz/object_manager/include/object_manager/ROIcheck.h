#include <geometry_msgs/Polygon.h>
bool isPointInPolygon(double x, double y, const geometry_msgs::Polygon& poly);