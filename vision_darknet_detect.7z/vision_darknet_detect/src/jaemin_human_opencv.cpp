#include<ros/ros.h>
#include"opencv2/opencv.hpp"
#include<iostream>
#include<autoware_msgs/DetectedObjectArray.h>
#include<vector>
#include"sensor_msgs/Image.h"

using namespace std;

Mat srcImage;

void callback(const autoware_msgs::DetectedObjectArrayConstPtr& ptr)
{
    srcImage = 
}

void callback_image(const sensor_msgs::ImageConstPtr& img)
{
    srcImage = img;
}
int main(int argc, char*argv[])
{
    ros::init(argc, argv, "jaemin_human_opencv");
    ros::NodeHandle nh;
    ros::Subscriber sub = nh.subscribe("/detection/image_detector/left_objects",1, callback);
}
