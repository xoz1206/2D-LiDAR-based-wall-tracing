#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
from rplidar_ros.msg import final_direction
# GPIO 라이브러리
import wiringpi
import math

PI = 3.1415926535

# 모터 상태
STOP  = 0
FORWARD  = 1
BACKWORD = 2

#   모터 채널
CH1 = 0
CH2 = 1

# PIN 입출력 설정
OUTPUT = 1
INPUT = 0

# PIN 설정
HIGH = 1
LOW = 0

# 실제 핀 정의
#PWM PIN
ENA = 25
ENB = 30

#GPIO PIN
IN1 = 24
IN2 = 23
IN3 = 22
IN4 = 21

#GPIO 라이브러리 설정
wiringpi.wiringPiSetup()

# 핀 설정 함수
def setPinConfig(EN, INA, INB):
    wiringpi.pinMode(EN, OUTPUT)
    wiringpi.pinMode(INA, OUTPUT)
    wiringpi.pinMode(INB, OUTPUT)
    wiringpi.softPwmCreate(EN, 0, 255)

# 모터 제어 함수
def setMotorControl(PWM, INA, INB, speed, stat):
    #모터 속도 제어 PWM
    wiringpi.softPwmWrite(PWM, speed)

    #앞으로
    if stat == FORWARD:
        wiringpi.digitalWrite(INA, HIGH)
        wiringpi.digitalWrite(INB, LOW)
    #뒤로
    elif stat == BACKWORD:
        wiringpi.digitalWrite(INA, LOW)
        wiringpi.digitalWrite(INB, HIGH)
    #정지
    elif stat == STOP:
        wiringpi.digitalWrite(INA, LOW)
        wiringpi.digitalWrite(INB, LOW)  

# 모터 제어함수 간단하게 사용하기 위해 한번더 래핑(감쌈)
def setMotor(ch, speed, stat):
    if ch == CH1:
        setMotorControl(ENA, IN1, IN2, speed, stat)
    else:
        setMotorControl(ENB, IN3, IN4, speed, stat)    


def msg_callback(data):
    #rospy.loginfo("go straight  : %d" % (data.go_straight))
    #rospy.loginfo("turn left    : %d" % (data.turn_left))
    #rospy.loginfo("turn right   : %d" % (data.turn_right))
    #rospy.loginfo("turn back    : %d" % (data.turn_back))
    #rospy.loginfo("goal point x : %f" % (data.go_x))
    #rospy.loginfo("goal point y : %f" % (data.go_y))

    go_straight = data.go_straight
    turn_left = data.turn_left
    turn_right = data.turn_right
    turn_back = data.turn_back
    x = data.go_x
    y = data.go_y

    if y > 0.0000001 :
        move_degree = atan(x/y) * 180 / PI

    elif y < 0.0000001 :
        move_degree = 0.0000000


    #모터 핀 설정
    setPinConfig(ENA, IN1, IN2)
    setPinConfig(ENB, IN3, IN4)

    #CH1 : 오른쪽
    #CH2 : 왼쪽
    if go_straight == True :

        if move_degree > 0 and abs(move_degree) > 5 : # 꺽어야 하는 각도가 5도보다 크고 오른쪽으로 꺾어야 하는 경우
            rospy.loginfo("살짝 오른쪽으로 직진합니다.")
            setMotor(CH1, 30, FORWARD)
            setMotor(CH2, 50, FORWARD)

        elif move_degree < 0 and abs(move_degree) > 5 : # 꺾어야 하는 각도가 5도보다 크고 왼쪽으로 꺾어야 하는 경우
            rospy.loginfo("살짝 왼쪽으로 직진합니다.")
            setMotor(CH1, 50, FORWARD)
            setMotor(CH2, 30, FORWARD)

        elif abs(move_degree) < 5 : # 꺾어야 하는 각도가 5도 이하인 경우
            rospy.loginfo("직진합니다.")
            setMotor(CH1, 30, FORWARD)
            setMotor(CH2, 50, FORWARD)


    elif turn_left == True :
        rospy.loginfo("좌측 90도 회전합니다.")
        setMotor(CH1, 50, BACKWORD)
        setMotor(CH2, 50, FORWARD)
        wiringpi.delay(2000) # 90도 정확하게 맞춰야 한다. 

    elif turn_right == True :
        rospy.loginfo("우측 90도 회전합니다.")
        setMotor(CH1, 50, FORWARD)
        setMotor(CH2, 50, BACKWORD)
        wiringpi.delay(2000) # 90도 정확하게 맞춰야 한다. 

    elif turn_back == True :
        rospy.loginfo("좌측 180도 회전합니다.")
        setMotor(CH1, 50, BACKWORD)
        setMotor(CH2, 50, FORWARD)
        wiringpi.delay(4000) # 180도 정확하게 맞춰야 한다.
    
    else :
        rospy.loginfo("아무것도 인식을 못했습니다. 살짝 오른쪽으로 직진합니다.")
        setMotor(CH1, 30, FORWARD)
        setMotor(CH2, 50, FORWARD)
        

def start_function():
    rospy.init_node('DC_controller', anonymous=True)
    rospy.Subscriber("/final_direction", final_direction, msg_callback)
    
    rospy.spin()

if __name__ == '__main__':
        main_function()